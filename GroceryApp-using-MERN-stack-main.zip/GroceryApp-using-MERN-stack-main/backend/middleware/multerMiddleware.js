// const multer = require("multer");
// console.log(__dirname);
// const upload = multer({
//   storage: multer.diskStorage({
//     destination: (req, file, cb) => {
//       cb(null, `backend/public/uploads/${file.fieldname}`);
//     },
//     filename: (req, file, cb) => {
//       cb(null, `${Date.now()}-${file.originalname}`);
//     },
//   }),
// });

// module.exports = upload;
